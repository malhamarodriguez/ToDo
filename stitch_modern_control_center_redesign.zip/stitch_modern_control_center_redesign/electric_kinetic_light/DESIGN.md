---
name: Electric Kinetic Light
colors:
  surface: '#f8fafb'
  surface-dim: '#d8dadb'
  surface-bright: '#f8fafb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f5'
  surface-container: '#eceeef'
  surface-container-high: '#e6e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#3b494c'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#eff1f2'
  outline: '#6b7a7d'
  outline-variant: '#bac9cc'
  surface-tint: '#006875'
  primary: '#006875'
  on-primary: '#ffffff'
  primary-container: '#00e5ff'
  on-primary-container: '#00626e'
  inverse-primary: '#00daf3'
  secondary: '#496268'
  on-secondary: '#ffffff'
  secondary-container: '#cce7ee'
  on-secondary-container: '#4f686e'
  tertiary: '#5e5e5e'
  on-tertiary: '#ffffff'
  tertiary-container: '#d1d0d0'
  on-tertiary-container: '#595959'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9cf0ff'
  primary-fixed-dim: '#00daf3'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004f58'
  secondary-fixed: '#cce7ee'
  secondary-fixed-dim: '#b0cbd2'
  on-secondary-fixed: '#041f24'
  on-secondary-fixed-variant: '#324b50'
  tertiary-fixed: '#e4e2e2'
  tertiary-fixed-dim: '#c7c6c6'
  on-tertiary-fixed: '#1b1c1c'
  on-tertiary-fixed-variant: '#464747'
  background: '#f8fafb'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  display-lg:
    fontFamily: Sora
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Sora
    fontSize: 36px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Sora
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Hanken Grotesk
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Hanken Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  button-text:
    fontFamily: Sora
    fontSize: 14px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.02em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: 40px
---

## Brand & Style
The design system emphasizes high-velocity movement and modern precision. It transitions from a dark-mode tech aesthetic to a "Clean-Tech" visual language, utilizing a bright, airy environment to make the vibrant accent colors feel more energetic and luminous. 

The style is a hybrid of **Minimalism** and **High-Contrast Modern**, utilizing expansive white space to ground the intense electric blue. The personality is optimistic, efficient, and forward-leaning, designed to evoke a sense of clarity and rapid interaction.

## Colors
This design system uses a stark, luminous palette to maximize the impact of the primary accent.

- **Primary (#00E5FF):** The "Kinetic Blue." Used for interactive states, progress indicators, and high-priority calls to action. It should appear to "glow" against the white background.
- **Secondary (#001A1F):** A deep, near-black teal. Used for primary typography and iconography to ensure maximum legibility and a sophisticated anchor to the light palette.
- **Neutral Backgrounds:** The base surface is pure white (#FFFFFF). Secondary surfaces or container backgrounds use a subtle cool grey (#F8FAFB).
- **Borders & Dividers:** Use a light grey (#E2E8F0) for structural definitions.

## Typography
The typography strategy pairs geometric tech-inspired headings with highly legible sans-serif body text.

- **Headlines:** Sora provides a futuristic, bold personality. Use heavy weights (700-800) for displays to create a strong visual hierarchy.
- **Body:** Hanken Grotesk is used for all long-form content and secondary UI text. It is clean, contemporary, and maintains a professional tone.
- **Data & Labels:** JetBrains Mono is utilized for technical labels, timestamps, and secondary metadata to reinforce the "kinetic" and technical nature of the system.

## Layout & Spacing
The system utilizes a **Fluid Grid** model with a strict 8px base unit. 

- **Layout:** Use a 12-column grid for desktop and a 4-column grid for mobile.
- **Rhythm:** Spacing between sections should be generous (64px+) to maintain the minimalist aesthetic. 
- **Alignment:** Elements should feel "snapped" to the grid. Use 24px gutters to allow the white space to breathe, preventing the high-contrast typography from feeling cluttered.

## Elevation & Depth
In this light mode variation, depth is achieved through **Tonal Layers** and **Subtle Outlines** rather than heavy shadows.

- **Surface Levels:** The primary background is white. Elevated cards or "floating" containers use the neutral grey (#F8FAFB) background with a 1px border (#E2E8F0).
- **Depth:** To signify interaction or hover, apply a very soft, high-diffusion blue-tinted shadow (Hex: #00E5FF at 10% opacity, 20px blur, 4px Y-offset).
- **Interaction:** Avoid skeuomorphism. Depth is strictly functional, moving "up" toward the user on interaction through slight border-color intensification.

## Shapes
The shape language is defined by extreme **Pill-shaped (Rounded-Full)** corners. 

All interactive elements—including buttons, input fields, and tags—should use a full corner radius where possible. Larger containers and cards should use `rounded-xl` (3rem/48px) to maintain a cohesive, "liquid" feel that contrasts against the sharp, geometric typography.

## Components
- **Buttons:** Primary buttons are solid Electric Blue (#00E5FF) with black or deep teal text. Secondary buttons are outlined with 2px borders. All buttons must be pill-shaped.
- **Input Fields:** Use a subtle grey background (#F8FAFB) with a bottom-only 2px border that turns Electric Blue on focus.
- **Chips & Tags:** Small, pill-shaped elements. Use the primary color at 10% opacity for the background and 100% opacity for the text.
- **Cards:** Cards should have no shadow by default, instead using a thin 1px border. On hover, the border changes to Electric Blue and a soft blue glow (shadow) is applied.
- **Lists:** Clean rows separated by thin (#E2E8F0) dividers. Use the JetBrains Mono label font for secondary list data to provide a "dashboard" feel.
- **Progress Indicators:** Use the primary Electric Blue for all active states, ensuring motion/animation is used (e.g., a pulsing glow) to signify "kinetic" activity.