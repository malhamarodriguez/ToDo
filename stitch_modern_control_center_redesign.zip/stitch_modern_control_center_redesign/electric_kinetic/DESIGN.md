---
name: Electric Kinetic
colors:
  surface: '#121318'
  surface-dim: '#121318'
  surface-bright: '#38393f'
  surface-container-lowest: '#0d0e13'
  surface-container-low: '#1a1b21'
  surface-container: '#1e1f25'
  surface-container-high: '#292a2f'
  surface-container-highest: '#34343a'
  on-surface: '#e3e1e9'
  on-surface-variant: '#bac9cc'
  inverse-surface: '#e3e1e9'
  inverse-on-surface: '#2f3036'
  outline: '#849396'
  outline-variant: '#3b494c'
  surface-tint: '#00daf3'
  primary: '#c3f5ff'
  on-primary: '#00363d'
  primary-container: '#00e5ff'
  on-primary-container: '#00626e'
  inverse-primary: '#006875'
  secondary: '#bdc2ff'
  on-secondary: '#1b247f'
  secondary-container: '#343d96'
  on-secondary-container: '#a8afff'
  tertiary: '#f1e9ff'
  on-tertiary: '#370096'
  tertiary-container: '#d6c9ff'
  on-tertiary-container: '#622be5'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#9cf0ff'
  primary-fixed-dim: '#00daf3'
  on-primary-fixed: '#001f24'
  on-primary-fixed-variant: '#004f58'
  secondary-fixed: '#e0e0ff'
  secondary-fixed-dim: '#bdc2ff'
  on-secondary-fixed: '#000767'
  on-secondary-fixed-variant: '#343d96'
  tertiary-fixed: '#e8deff'
  tertiary-fixed-dim: '#cdbdff'
  on-tertiary-fixed: '#20005f'
  on-tertiary-fixed-variant: '#4f00d0'
  background: '#121318'
  on-background: '#e3e1e9'
  surface-variant: '#34343a'
typography:
  headline-xl:
    fontFamily: Geist
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Geist
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Geist
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: '0'
  body-md:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: '0'
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  container-max: 1440px
  gutter: 24px
  margin-desktop: 64px
  margin-mobile: 20px
---

## Brand & Style
The brand personality is high-octane, technical, and precise. It targets a demographic of power users, developers, and performance-oriented professionals who value speed and clarity. The UI evokes a sense of controlled energy—like a high-performance machine idling in the dark.

The design style is **High-Contrast / Modern**, blending elements of **Minimalism** with **Glassmorphism**. It utilizes deep, ink-like backgrounds to make vibrant, "kinetic" blue accents pop with maximum luminosity. The aesthetic avoids unnecessary decoration, focusing instead on structural integrity, sharp execution, and data density.

## Colors
The palette is engineered for high-performance dark mode environments.

*   **Primary (#00E5FF):** An "Electric Cyan" used for critical actions, active states, and focus indicators. It provides a sharp, energetic contrast against the dark base.
*   **Secondary (#1A237E):** A "Deep Indigo" used for subtle structural highlights and secondary buttons, bridging the gap between the black background and bright accents.
*   **Tertiary (#7C4DFF):** A "Neon Violet" used for data visualization, secondary status indicators, or to differentiate logic flows.
*   **Neutral (#0A0B10):** A "Midnight Obsidian" serving as the foundational surface color, deeper than standard grays to ensure the primary accents feel truly kinetic.

## Typography
The typography system prioritizes legibility and a "technical" atmosphere. 

**Geist** is used for headlines and body copy to provide a clean, neo-grotesque look that feels modern and precise. **JetBrains Mono** is reserved for labels, metadata, and data points to reinforce the technical, developer-centric aesthetic. 

Headlines use tight letter spacing and heavy weights to command attention, while body text remains airy to ensure long-term readability in dark mode. Labels are always capitalized or tracked out slightly for a sophisticated, "instrument-panel" feel.

## Layout & Spacing
The system utilizes a **Fluid Grid** with a strict 8px spacing power-of-two rhythm. 

*   **Desktop:** A 12-column grid with 24px gutters. Side margins are generous (64px) to keep content focused.
*   **Tablet:** An 8-column grid with 20px gutters. 
*   **Mobile:** A 4-column grid with 16px gutters and 20px margins.

Layouts should favor verticality and clear information grouping. Use generous padding within containers (minimum 24px) to prevent the high-contrast elements from feeling cluttered.

## Elevation & Depth
Elevation is communicated through **Tonal Layers** and **Glassmorphism**, rather than traditional heavy shadows.

*   **Level 0 (Base):** #0A0B10 (Midnight Obsidian).
*   **Level 1 (Cards/Panels):** #161821 (A slightly lighter navy-gray) with a 1px border of #ffffff10.
*   **Level 2 (Modals/Popovers):** #1C1F2B with a subtle backdrop blur (12px) and a slightly more prominent border (#ffffff15).
*   **Accents:** Interactive elements use an inner glow or "Electric" bloom effect (0px 0px 12px #00E5FF40) instead of a black shadow to simulate light emission.

## Shapes
The shape language is **Soft** but disciplined. 

A corner radius of `4px` (0.25rem) is the standard for buttons and inputs, providing a sharp, professional look that isn't as aggressive as pure 0px corners. Larger components like cards use `8px` (0.5rem), and major containers use `12px` (0.75rem). This hierarchy of roundedness ensures that smaller, interactive elements feel like precise tools, while larger containers feel like stable structures.

## Components

*   **Buttons:** Primary buttons are solid #00E5FF with black text for maximum contrast. Secondary buttons are outlined with #00E5FF and use transparent backgrounds.
*   **Inputs:** Fields use the Level 1 surface color with a 1px border. On focus, the border transitions to #00E5FF with a subtle outer "glow" bloom.
*   **Chips:** Use JetBrains Mono for text. Backgrounds are #1A237E (Secondary) with high-contrast text to distinguish them from actionable buttons.
*   **Lists:** Items are separated by subtle 1px lines (#ffffff08). Hover states should use a slight background tint increase rather than a color change.
*   **Cards:** Use the Level 1 background. Borders are mandatory to define boundaries in the deep dark environment.
*   **Checkboxes/Radios:** When active, these should "glow" in Primary Cyan. Unselected states should be high-contrast outlines to remain visible against the dark background.
*   **Data Visuals:** Use Primary (Cyan) for the main data stream, Tertiary (Violet) for comparisons, and a high-visibility White for grid lines/axes.